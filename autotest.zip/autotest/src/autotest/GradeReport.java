package autotest;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class GradeReport {
     public static void main(String[] args) throws InterruptedException, FileNotFoundException, UnsupportedEncodingException 
     {
         // Create a new instance of the Firefox driver
         System.setProperty("webdriver.chrome.driver", "C:\\Gecko\\chromedriver.exe");
         WebDriver driver;
         driver = new ChromeDriver();
         //Launch site
         driver.get("https://portal.aait.edu.et");
        
         driver.findElement(By.xpath(".//*[@id=\"UserName\"]")).sendKeys("Atr/7842/09");  
         driver.findElement(By.xpath(".//*[@id=\"Password\"]")).sendKeys("8611");  
         
          
       driver.findElement(By.xpath(".//*[@id=\"home\"]/div[2]/div[2]/form/div[4]/div/button")).click(); 
       String url="https://portal.aait.edu.et/Grade/GradeReport";
       driver.navigate().to(url);
       driver.navigate().refresh();
       String gradeReport= driver.findElement(By.xpath(".//html/body/div[2]/div/div[2]/div[1]/div/div/table")).getText(); 
       System.out.println(gradeReport);
    
       PrintWriter writer = new PrintWriter("C://Grade/grade.txt", "UTF-8");
       writer.println(gradeReport);
       writer.close();


        Thread.sleep(5000);
         driver.quit();
         

}
}

